import { type User, type InsertUser, type Product, type InsertProduct, type Contact, type InsertContact, type Booking, type InsertBooking, type CartItem, type InsertCartItem } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Product methods
  getAllProducts(): Promise<Product[]>;
  getProductById(id: string): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Cart methods
  getCartItems(sessionId: string): Promise<(CartItem & { product: Product })[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: string): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;

  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getAllContacts(): Promise<Contact[]>;

  // Booking methods
  createBooking(booking: InsertBooking): Promise<Booking>;
  getAllBookings(): Promise<Booking[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private cartItems: Map<string, CartItem>;
  private contacts: Map<string, Contact>;
  private bookings: Map<string, Booking>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.contacts = new Map();
    this.bookings = new Map();
    this.initializeProducts();
  }

  private initializeProducts() {
    const sampleProducts: Product[] = [
      {
        id: "1",
        name: "Samsung 500L Double Door Refrigerator",
        description: "Energy-efficient double door refrigerator with digital inverter technology and spacious storage compartments.",
        category: "refrigerators",
        brand: "Samsung",
        price: "1299.00",
        originalPrice: "1499.00",
        discount: 13,
        rating: "4.8",
        reviewCount: 125,
        images: ["https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "500L",
          "Type": "Double Door",
          "Energy Rating": "5 Star",
          "Compressor": "Digital Inverter",
          "Warranty": "10 Years on Compressor"
        },
        features: ["Digital Inverter Technology", "All Around Cooling", "Deodorizer", "LED Lighting"],
        inStock: true,
        stockQuantity: 15,
        tags: ["bestseller", "energy-efficient"],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "2",
        name: "LG 4 Burner Glass Top Gas Stove",
        description: "Premium glass top gas stove with high-efficiency burners and auto-ignition system.",
        category: "cooking",
        brand: "LG",
        price: "399.00",
        originalPrice: "459.00",
        discount: 13,
        rating: "4.6",
        reviewCount: 89,
        images: ["https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Burners": "4 Brass Burners",
          "Top Material": "Toughened Glass",
          "Ignition": "Manual",
          "Gas Type": "LPG",
          "Warranty": "2 Years"
        },
        features: ["Toughened Glass Top", "High Efficiency Burners", "Easy to Clean", "Elegant Design"],
        inStock: true,
        stockQuantity: 8,
        tags: ["energy-star"],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "3",
        name: "Havells 25L Instant Water Heater",
        description: "Instant electric water heater with advanced safety features and energy-efficient heating element.",
        category: "water-heating",
        brand: "Havells",
        price: "189.00",
        originalPrice: null,
        discount: 0,
        rating: "4.4",
        reviewCount: 67,
        images: ["https://images.unsplash.com/photo-1560185007-cde436f6a4d0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "25 Liters",
          "Type": "Storage",
          "Heating Element": "Copper",
          "Power": "2000W",
          "Warranty": "5 Years on Tank"
        },
        features: ["Instant Heating", "Safety Valve", "Corrosion Resistant", "Energy Efficient"],
        inStock: true,
        stockQuantity: 12,
        tags: ["new-arrival"],
        isFeatured: true,
        isNew: true,
        createdAt: new Date()
      },
      {
        id: "4",
        name: "Blue Star Water Cooler 40L",
        description: "Commercial grade water cooler with high cooling capacity and stainless steel construction.",
        category: "water-cooling",
        brand: "Blue Star",
        price: "599.00",
        originalPrice: "699.00",
        discount: 14,
        rating: "4.7",
        reviewCount: 94,
        images: ["https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "40 Liters",
          "Cooling Type": "Compressor",
          "Material": "Stainless Steel",
          "Power": "150W",
          "Warranty": "1 Year Comprehensive"
        },
        features: ["High Cooling Capacity", "Stainless Steel Body", "Energy Efficient", "Easy Maintenance"],
        inStock: true,
        stockQuantity: 6,
        tags: [],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "5",
        name: "Voltas Commercial Deep Freezer",
        description: "High-capacity commercial deep freezer for restaurants and commercial establishments.",
        category: "commercial",
        brand: "Voltas",
        price: "2499.00",
        originalPrice: "2799.00",
        discount: 11,
        rating: "4.5",
        reviewCount: 45,
        images: ["https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "500 Liters",
          "Type": "Deep Freezer",
          "Temperature Range": "-18°C to -24°C",
          "Defrost": "Manual",
          "Warranty": "2 Years Comprehensive"
        },
        features: ["High Storage Capacity", "Energy Efficient", "Robust Construction", "Temperature Control"],
        inStock: true,
        stockQuantity: 3,
        tags: ["commercial"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      }
    ];

    sampleProducts.forEach(product => {
      this.products.set(product.id, product);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.category === category
    );
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.isFeatured
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) =>
        product.name.toLowerCase().includes(lowerQuery) ||
        product.description.toLowerCase().includes(lowerQuery) ||
        product.brand.toLowerCase().includes(lowerQuery) ||
        product.category.toLowerCase().includes(lowerQuery)
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id, 
      originalPrice: insertProduct.originalPrice || null,
      discount: insertProduct.discount || null,
      rating: insertProduct.rating || null,
      reviewCount: insertProduct.reviewCount || null,
      stockQuantity: insertProduct.stockQuantity || null,
      tags: insertProduct.tags as string[] | null || null,
      isFeatured: insertProduct.isFeatured || null,
      isNew: insertProduct.isNew || null,
      createdAt: new Date() 
    };
    this.products.set(id, product);
    return product;
  }

  async getCartItems(sessionId: string): Promise<(CartItem & { product: Product })[]> {
    const items = Array.from(this.cartItems.values()).filter(
      (item) => item.sessionId === sessionId
    );
    
    const itemsWithProducts = [];
    for (const item of items) {
      const product = this.products.get(item.productId);
      if (product) {
        itemsWithProducts.push({ ...item, product });
      }
    }
    
    return itemsWithProducts;
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists
    const existingItem = Array.from(this.cartItems.values()).find(
      (item) => item.sessionId === insertItem.sessionId && item.productId === insertItem.productId
    );

    if (existingItem) {
      // Update quantity
      existingItem.quantity += (insertItem.quantity || 1);
      this.cartItems.set(existingItem.id, existingItem);
      return existingItem;
    } else {
      // Create new item
      const id = randomUUID();
      const cartItem: CartItem = { 
        ...insertItem, 
        id, 
        quantity: insertItem.quantity || 1,
        createdAt: new Date() 
      };
      this.cartItems.set(id, cartItem);
      return cartItem;
    }
  }

  async updateCartItem(id: string, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (item) {
      item.quantity = quantity;
      this.cartItems.set(id, item);
      return item;
    }
    return undefined;
  }

  async removeFromCart(id: string): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const items = Array.from(this.cartItems.entries()).filter(
      ([_, item]) => item.sessionId === sessionId
    );
    
    items.forEach(([id]) => {
      this.cartItems.delete(id);
    });
    
    return true;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id, 
      phone: insertContact.phone || null,
      status: "pending",
      createdAt: new Date() 
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getAllContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = randomUUID();
    const booking: Booking = { 
      ...insertBooking, 
      id, 
      productType: insertBooking.productType || null,
      message: insertBooking.message || null,
      status: "pending",
      createdAt: new Date() 
    };
    this.bookings.set(id, booking);
    return booking;
  }

  async getAllBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }
}

export const storage = new MemStorage();
