export interface Category {
  id: string;
  name: string;
  icon: string;
  productCount?: number;
}

export interface CartItemWithProduct {
  id: string;
  sessionId: string;
  productId: string;
  quantity: number;
  createdAt: Date;
  product: {
    id: string;
    name: string;
    price: string;
    images: string[];
    inStock: boolean;
  };
}

export interface SearchFilters {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  brand?: string;
  inStock?: boolean;
}
