import { Award, Users, Target, CheckCircle, Shield, Clock, Wrench, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function About() {
  const stats = [
    { number: "15+", label: "Years of Experience", icon: Clock },
    { number: "10,000+", label: "Happy Customers", icon: Users },
    { number: "50+", label: "Brand Partners", icon: Award },
    { number: "24/7", label: "Customer Support", icon: Shield },
  ];

  const values = [
    {
      icon: Target,
      title: "Our Mission",
      description: "To provide premium quality home and commercial appliances with exceptional service, ensuring customer satisfaction and long-term reliability."
    },
    {
      icon: Users,
      title: "Customer First",
      description: "We prioritize our customers' needs, offering personalized solutions and comprehensive support throughout their appliance journey."
    },
    {
      icon: Award,
      title: "Quality Assurance",
      description: "We partner only with trusted brands and maintain rigorous quality standards to deliver products that exceed expectations."
    },
    {
      icon: Wrench,
      title: "Expert Service",
      description: "Our certified technicians provide professional installation, maintenance, and repair services with guaranteed workmanship."
    },
  ];

  const team = [
    {
      name: "Hassan Ali",
      position: "Founder & CEO",
      experience: "20+ years in appliance industry",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      description: "Visionary leader with extensive experience in electronics retail and customer service excellence."
    },
    {
      name: "Sara Ahmed",
      position: "Technical Director",
      experience: "15+ years in appliance technology",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b647?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      description: "Expert in appliance technology and installation processes, ensuring quality service delivery."
    },
    {
      name: "Mohammad Khan",
      position: "Service Manager",
      experience: "12+ years in customer service",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      description: "Dedicated to providing exceptional customer support and managing service operations efficiently."
    },
  ];

  const certifications = [
    "ISO 9001:2015 Quality Management",
    "Energy Star Partner Certification",
    "Authorized Service Provider",
    "Better Business Bureau A+ Rating",
    "Green Business Certification",
    "Industry Safety Standards Compliant"
  ];

  const achievements = [
    "Best Electronics Retailer 2023",
    "Customer Service Excellence Award",
    "Top Appliance Dealer - Regional",
    "Environmental Responsibility Recognition",
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-background to-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-about-title">
              About Hassan Electronics
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed" data-testid="text-about-description">
              For over 15 years, Hassan Electronics has been the trusted choice for premium home and commercial appliances. 
              We combine quality products with exceptional service to deliver complete satisfaction to our customers.
            </p>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
              {stats.map((stat, index) => (
                <div key={index} className="text-center" data-testid={`stat-${index}`}>
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <stat.icon className="h-8 w-8 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-1" data-testid="text-stat-number">
                    {stat.number}
                  </div>
                  <div className="text-sm text-muted-foreground" data-testid="text-stat-label">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6" data-testid="text-story-title">Our Story</h2>
              <div className="space-y-4 text-muted-foreground">
                <p data-testid="text-story-paragraph-1">
                  Hassan Electronics was founded in 2008 with a simple vision: to provide high-quality appliances 
                  and exceptional service to homes and businesses in our community. What started as a small family 
                  business has grown into a trusted regional leader in appliance retail and service.
                </p>
                <p data-testid="text-story-paragraph-2">
                  Our founder, Hassan Ali, recognized the need for a reliable appliance provider that combined 
                  product expertise with genuine customer care. Today, we continue that tradition by offering 
                  comprehensive solutions from initial consultation to long-term maintenance support.
                </p>
                <p data-testid="text-story-paragraph-3">
                  We've built lasting relationships with leading manufacturers and maintained our commitment to 
                  quality, innovation, and customer satisfaction. Our team of certified professionals ensures 
                  that every customer receives the best possible experience.
                </p>
              </div>
            </div>
            
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
                alt="Hassan Electronics store front"
                className="rounded-lg shadow-lg w-full"
                data-testid="img-store-front"
              />
              <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-4 rounded-lg shadow-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold">15+</div>
                  <div className="text-sm">Years Serving</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-values-title">Our Values</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-values-description">
              The principles that guide everything we do, from product selection to customer service.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="h-full" data-testid={`card-value-${index}`}>
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <value.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-2" data-testid="text-value-title">
                        {value.title}
                      </h3>
                      <p className="text-muted-foreground" data-testid="text-value-description">
                        {value.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-team-title">Meet Our Team</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-team-description">
              Experienced professionals dedicated to providing exceptional service and expertise.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="text-center" data-testid={`card-team-member-${index}`}>
                <CardContent className="p-6">
                  <div className="w-32 h-32 mx-auto mb-4 overflow-hidden rounded-full">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                      data-testid="img-team-member"
                    />
                  </div>
                  <h3 className="font-semibold text-lg mb-1" data-testid="text-member-name">
                    {member.name}
                  </h3>
                  <p className="text-primary font-medium mb-2" data-testid="text-member-position">
                    {member.position}
                  </p>
                  <Badge variant="secondary" className="mb-3" data-testid="badge-member-experience">
                    {member.experience}
                  </Badge>
                  <p className="text-sm text-muted-foreground" data-testid="text-member-description">
                    {member.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications & Achievements */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Certifications */}
            <div>
              <h2 className="text-2xl font-bold mb-6" data-testid="text-certifications-title">
                Certifications & Standards
              </h2>
              <div className="space-y-3">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center space-x-3" data-testid={`certification-${index}`}>
                    <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span>{cert}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Achievements */}
            <div>
              <h2 className="text-2xl font-bold mb-6" data-testid="text-achievements-title">
                Awards & Recognition
              </h2>
              <div className="space-y-3">
                {achievements.map((achievement, index) => (
                  <div key={index} className="flex items-center space-x-3" data-testid={`achievement-${index}`}>
                    <Star className="h-5 w-5 text-yellow-500 flex-shrink-0" />
                    <span>{achievement}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-why-choose-title">
              Why Choose Hassan Electronics?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center" data-testid="card-quality-products">
              <CardContent className="p-6">
                <Award className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Quality Products</h3>
                <p className="text-muted-foreground text-sm">
                  We partner with leading brands to offer only the highest quality appliances with proven reliability.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center" data-testid="card-expert-service">
              <CardContent className="p-6">
                <Wrench className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Expert Service</h3>
                <p className="text-muted-foreground text-sm">
                  Our certified technicians provide professional installation, maintenance, and repair services.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center" data-testid="card-customer-support">
              <CardContent className="p-6">
                <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Customer Support</h3>
                <p className="text-muted-foreground text-sm">
                  24/7 customer support ensures you always have help when you need it most.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
