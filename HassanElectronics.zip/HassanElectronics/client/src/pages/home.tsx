import { useQuery } from "@tanstack/react-query";
import { ArrowRight, ShieldCheck, Truck, Wrench, Clock, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ProductCard } from "@/components/product-card";
import { CategoryCard } from "@/components/category-card";
import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Category } from "@/lib/types";

export default function Home() {
  const { data: featuredProducts = [] } = useQuery<Product[]>({
    queryKey: ["/api/products?featured=true"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const trustIndicators = [
    { icon: ShieldCheck, title: "5 Year Warranty", description: "Comprehensive warranty coverage" },
    { icon: Truck, title: "Free Delivery", description: "Free shipping on all orders" },
    { icon: Wrench, title: "Expert Installation", description: "Professional setup service" },
    { icon: Clock, title: "24/7 Support", description: "Round-the-clock assistance" },
  ];

  const testimonials = [
    {
      id: 1,
      name: "Ahmad Khan",
      role: "Homeowner",
      rating: 5,
      comment: "Excellent service and quality products. The refrigerator we bought has been working perfectly for 2 years. Installation was professional and on time.",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
    },
    {
      id: 2,
      name: "Sarah Ahmed",
      role: "Restaurant Owner",
      rating: 5,
      comment: "Best place for commercial equipment! We equipped our entire restaurant kitchen through Hassan Electronics. Great prices and after-sales support.",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b647?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
    },
    {
      id: 3,
      name: "Rajesh Patel",
      role: "Office Manager",
      rating: 5,
      comment: "Professional team with excellent technical knowledge. They helped us choose the right water cooler for our office and installation was seamless.",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
    },
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden hero-gradient">
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 to-background/70 z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        />
        
        <div className="relative z-20 container mx-auto px-4 lg:px-6 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-foreground leading-tight" data-testid="text-hero-title">
              Premium Home & 
              <span className="text-primary"> Commercial Appliances</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-hero-description">
              Discover our extensive collection of refrigerators, stoves, geysers, water coolers, and commercial equipment. Professional installation and maintenance services included.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/products">
                <Button size="lg" className="flex items-center space-x-2" data-testid="button-shop-now">
                  <span>Shop Now</span>
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="flex items-center space-x-2" data-testid="button-watch-demo">
                <span>Watch Demo</span>
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              {trustIndicators.map((indicator, index) => (
                <div key={index} className="flex flex-col items-center" data-testid={`trust-indicator-${index}`}>
                  <indicator.icon className="h-8 w-8 text-primary mb-2" />
                  <span className="text-sm font-medium" data-testid="text-trust-title">{indicator.title}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-categories-title">Shop by Category</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-categories-description">
              Explore our comprehensive range of home and commercial appliances, each category featuring top brands and latest models.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-featured-title">Featured Products</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-featured-description">
              Discover our most popular appliances, carefully selected for their quality, efficiency, and customer satisfaction.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/products">
              <Button variant="secondary" size="lg" data-testid="button-view-all-products">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-testimonials-title">What Our Customers Say</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-testimonials-description">
              Read testimonials from satisfied customers who trust Hassan Electronics for their appliance needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="h-full" data-testid={`card-testimonial-${testimonial.id}`}>
                <CardContent className="p-6 flex flex-col h-full">
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 flex-1" data-testid="text-testimonial-comment">
                    "{testimonial.comment}"
                  </p>
                  <div className="flex items-center space-x-3">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                      data-testid="img-testimonial-avatar"
                    />
                    <div>
                      <p className="font-semibold" data-testid="text-testimonial-name">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground" data-testid="text-testimonial-role">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
