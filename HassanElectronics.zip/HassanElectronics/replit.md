# Hassan Electronics E-commerce Website

## Overview

Hassan Electronics is a comprehensive e-commerce platform for home and commercial appliances retail. The application serves as a modern, responsive web store specializing in refrigerators, cooking equipment, water heating systems, water cooling solutions, and commercial appliances. The platform provides a complete shopping experience with product catalog browsing, shopping cart functionality, contact forms, service booking, and detailed product information.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React SPA**: Single-page application built with React 18, TypeScript, and Vite for fast development and optimized production builds
- **Routing**: Client-side routing implemented with Wouter for lightweight navigation
- **UI Framework**: Radix UI primitives with shadcn/ui components for accessible, customizable interface elements
- **Styling**: Tailwind CSS with CSS custom properties for theming, following a design system with consistent spacing, colors, and typography
- **State Management**: TanStack Query (React Query) for server state management, caching, and data synchronization
- **Form Handling**: React Hook Form with Zod schema validation for type-safe form processing

### Backend Architecture
- **Node.js Server**: Express.js REST API server with TypeScript for type safety
- **Session Management**: In-memory session handling for cart persistence across page refreshes
- **Storage Layer**: Abstracted storage interface with in-memory implementation, designed for easy migration to database
- **API Design**: RESTful endpoints for products, cart operations, contacts, and service bookings
- **Development Setup**: Vite middleware integration for hot module replacement in development

### Data Storage Solutions
- **Current**: In-memory storage with pre-seeded product data for development and demonstration
- **Database Ready**: Drizzle ORM configuration with PostgreSQL schema definitions for production deployment
- **Schema Design**: Well-structured tables for users, products, cart items, contacts, and service bookings with proper relationships and constraints

### Product Catalog System
- **Categories**: Organized product hierarchy (refrigerators, cooking, water-heating, water-cooling, commercial)
- **Product Features**: Rich product data including specifications, features, pricing, images, ratings, and inventory tracking
- **Search & Filtering**: Category-based filtering, text search, price range filtering, brand filtering, and stock availability filtering
- **Shopping Cart**: Session-based cart with quantity management, real-time total calculations, and persistence

### External Dependencies

- **@neondatabase/serverless**: Serverless PostgreSQL database adapter for production deployment
- **@radix-ui/***: Comprehensive set of accessible UI primitives for form controls, navigation, dialogs, and interactive components
- **@tanstack/react-query**: Server state management library for API data fetching, caching, and synchronization
- **drizzle-orm & drizzle-kit**: Type-safe SQL toolkit and migration system for PostgreSQL database operations
- **tailwindcss**: Utility-first CSS framework with PostCSS processing for responsive design
- **wouter**: Minimalist router for React applications with hooks-based navigation
- **react-hook-form & @hookform/resolvers**: Form state management with validation resolver integration
- **zod & drizzle-zod**: Runtime type validation and schema generation for API request/response validation
- **lucide-react**: Icon library providing consistent iconography throughout the application
- **class-variance-authority & clsx**: Utility libraries for conditional CSS class management and component variants